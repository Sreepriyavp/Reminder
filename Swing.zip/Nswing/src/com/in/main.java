package com.in;

import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.SimpleDateFormat;

public class main extends JFrame {
    private JPanel jpcalan;
    private JLabel label1;
    private JLabel label2;
    private JPanel Jpcal;

    private JButton submitButton;
    private JTextArea textArea;
    private JPanel calpan;
    private JButton check;
    private JButton button12;
    JDateChooser  datahose=new JDateChooser();
    SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy/MM/dd");
ResultSet rs=null;
DB ob=  new DB();
int flag=0;

    public main(){

        setContentPane(jpcalan) ;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setSize(400,350);

        datahose.setDateFormatString("yyyy/MM/dd");calpan.add(datahose);
        submitButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                  String as=textArea.getText();
                  String dt=simpleDateFormat.format(datahose.getDate());



           rs=    ob.checkid(dt);
           try {
               while (rs.next()) {
                   System.out.println(rs.getInt("id"));
                   int i = rs.getInt("id");
                   System.out.println(flag);
                   while (flag==1){
                       ob.insertup(as,i);
                   }
               ob.insertde(i,as);

               }
           }  catch (SQLException e1) {
               e1.printStackTrace();
           }



            }
        });
        check.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{ Class.forName("com.mysql.jdbc.Driver");
                    Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hai","root","root"); String query="select tect from inse where date=?";
                    PreparedStatement statement=con.prepareStatement(query);String at=simpleDateFormat.format(datahose.getDate());
                    statement.setString(1,at);

          rs=statement.executeQuery();
       while(rs.next()) {
           textArea.setText(rs.getString("tect"));
           flag=1;

       }textArea.setText("");


             } catch (ClassNotFoundException e2) {
                    e2.printStackTrace();
                } catch (SQLException e2) {
                    e2.printStackTrace();
                }

            }
        });

        button12.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hai","root","root");

                    String query="delete from inse where  date=?";
                    PreparedStatement statement=con.prepareStatement(query);String qdt=simpleDateFormat.format(datahose.getDate());
                    statement.setString(1,qdt);

                    statement.execute();
                    JOptionPane.showMessageDialog(null,"it sucess");
                    textArea.setText("");

                }catch (ClassNotFoundException| SQLException qee){ qee.printStackTrace(); }
          jpcalan.revalidate();
                jpcalan.repaint();
            }
        });
    }

    public static void main(String[] args) {
        new main().setVisible(true);

    }
}
