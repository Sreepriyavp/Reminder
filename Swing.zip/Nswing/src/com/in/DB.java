package com.in;

import javax.swing.*;
import java.sql.*;

public class DB {
    Connection con=null;
    ResultSet rs=null;

    public DB() {

        try {
            Class.forName("com.mysql.jdbc.Driver");
      con  = DriverManager.getConnection("jdbc:mysql://localhost:3306/hai", "root", "root");


        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



    public void insertde(int i,String as) {
        try {
            String query = "insert into inse(id,tect) values(?,?)";
            PreparedStatement statement = con.prepareStatement(query);
            statement.setInt(1, i);

            statement.setString(2, as);
            statement.execute();
        }catch (SQLException e1){}
    }

    public void insertup(String textArea, int i) {
        try {
            String quey = "update  inse  set tect=? where id=?";
            PreparedStatement statement = con.prepareStatement(quey);
            statement.setString(1, textArea);
           statement.setInt(2,i);
    statement.executeUpdate();
       }catch (SQLException e12){}
}

    public ResultSet checkid(String dt) {
        try {
            String quey = "select id from inse where  date=?";
            PreparedStatement statement = con.prepareStatement(quey);
            statement.setString(1, dt);
              rs= statement.executeQuery();
            System.out.println(rs.getInt("id"));

        }catch (SQLException e123){}
        return rs;
    }
    }

